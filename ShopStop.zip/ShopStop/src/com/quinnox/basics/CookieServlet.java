package com.quinnox.basics;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class CookieServlet
 */
@WebServlet("/CookieServlet")
public class CookieServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CookieServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		try
		{
		PrintWriter pw = response.getWriter();
		response.setContentType("text/html");
		HttpSession session = request.getSession();

		String user = request.getParameter("username");
		String pass = request.getParameter("userPassword");
		pw.print("Hello Here:\t"+user);
		pw.print("Your Password is:\t "+pass);
		pw.println("\n\n\nSession  id is :"+session.getId()+"<br/>");
		pw.println("\nTime is:"+new Date(session.getLastAccessedTime())+"<br/>");
		
		Cookie c1 = new Cookie("Username",user);
		Cookie c2 = new Cookie("userPassword",pass);
		
		response.addCookie(c1);
		response.addCookie(c2);
		
		pw.print("<a href='WelcomeCookie'>View Details</a>");
		pw.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
