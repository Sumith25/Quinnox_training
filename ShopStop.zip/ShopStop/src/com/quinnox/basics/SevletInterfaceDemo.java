package com.quinnox.basics;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

/**
 * Servlet implementation class SevletInterfaceDemo
 */
@WebServlet("/SevletInterfaceDemo")
public class SevletInterfaceDemo implements Servlet {
	ServletConfig config = null;

    /**
     * Default constructor. 
     */
    public SevletInterfaceDemo() {
        // TODO Auto-generated constructor stub
    }
    
	public void init(ServletConfig config) throws ServletException {
    	this.config = config;
    	System.out.println("Servlet i Intialized:");
    }
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException
    {
    	res.setContentType("text/html");
    	
    	PrintWriter out = res.getWriter();
    	out.print("<html><body>");
    	out.println("<b>Hello Servlet</b>");
    	out.print("</body></html>");
    	
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
		// TODO Auto-generated method stu

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Servlet#getServletConfig()
	 */
	public ServletConfig getServletConfig() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @see Servlet#getServletInfo()
	 */
	public String getServletInfo() {
		// TODO Auto-generated method stub
		return null; 
	}

	/**
	 * @see Servlet#service(ServletRequest request, ServletResponse response)
	 */
		// TODO Auto-generated method stub

}
